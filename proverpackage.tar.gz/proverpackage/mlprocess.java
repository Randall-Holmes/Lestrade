import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.text.*;



class mlprocess

{ 

    //public InputStreamReader MLInput;
public BufferedReader MLInput;
public OutputStreamWriter MLOutput;
    public JTextArea InputTextArea;
    public JTextArea OutputTextArea;
    public String TheFileName;
    

private Process TheProcess;

    public mlprocess(String filename)

    {   try{

	TheFileName = filename;


Process x;

       x = (Runtime.getRuntime()).exec("mosml"); 
       TheProcess = x;

       InputStream A;

       A = x.getInputStream();

       InputStreamReader B;

       B = new InputStreamReader(A);

       BufferedReader C;

       C = new BufferedReader(B);

       MLInput = C;     

     OutputStream z;

     z = x.getOutputStream();

     OutputStreamWriter z2;

     z2 = new OutputStreamWriter(z);

     MLOutput = z2;

     InputTextArea = new JTextArea();

     JTextArea zzz = new JTextArea();

     OutputTextArea = zzz;

     //     OutputTextArea.setContentType("text/plain");

     // MLOutput.write(("val Quit = quit;\n").toCharArray(),0,17);
     // MLOutput.flush();

MLOutput.write(("load \"segments\";open segments;\n\n").toCharArray(),0,32);
MLOutput.flush();




}

catch (IOException e){System.out.println(e);}}


public void putwindow(JTextArea localwindow,JTextArea globalwindow,
		      JTextArea equationwindow) {
    try{


  MLOutput.write(("\nguistart();\n").toCharArray(),0,13);
	MLOutput.flush();



	if(OutputTextArea.getSelectedText()==null) {OutputTextArea.write(MLOutput);}

        else {MLOutput.write(OutputTextArea.getSelectedText(),0,OutputTextArea.getSelectedText().length());}
	MLOutput.flush();



MLOutput.write(("\nguidone();\n").toCharArray(),0,12);
MLOutput.flush();
String t;int temp;t = "";




while(!(t.equals("GUISTART")))

{

    //    System.out.println((t).toCharArray());
t = MLInput.readLine();

}

t = MLInput.readLine();
t = MLInput.readLine();
t = MLInput.readLine();



// echo the command line

// System.out.println(("Command> "+s1+"\n").toCharArray());

while(!(t.equals("GUIDONE")) && !(t.equals("guidone();")))

{

    

    if (t.equals("Global term display:")||t.equals("Initial term display:")
	||t.equals("OUTPUT term display:"))
	{globalwindow.setText("");
	{while (!t.equals(". . .")) {
	    //	    t = MLInput.readLine();    
InputTextArea.append(t+"\n");
globalwindow.append(t+"\n");
t = MLInput.readLine();
        }}
InputTextArea.append(t+"\n");
	}

else {if (t.equals("Local term display:") ||t.equals("INPUT term display:") )
	{localwindow.setText("");
	{while (!t.equals(". . .")) {
	    //	    t = MLInput.readLine();    
InputTextArea.append(t+"\n");
localwindow.append(t+"\n");
t = MLInput.readLine();
        }}
InputTextArea.append(t+"\n");
	}

else {if (t.equals("Equation display:") ||t.equals("Statement display:")||t.equals("Hypothesis display:")||(t.equals("Table display:")))
	{equationwindow.setText("");
	{while (!t.equals(". . .")) {
	    //	    t = MLInput.readLine();    
InputTextArea.append(t+"\n");
equationwindow.append(t+"\n");
t = MLInput.readLine();
        }}
InputTextArea.append(t+"\n");
	}

else{InputTextArea.append(t+"\n");}}}

  


if (t.length() >=7 && (t.substring(0,7)).equals("Watson:"))
	{
	    MLOutput.write(("guidone();\n").toCharArray(),0,11); 
            MLOutput.flush();
            equationwindow.append(t+"\n");
            localwindow.append(t+"\n");
            globalwindow.append(t+"\n");
            t = MLInput.readLine();
	    }

	else{    


    t = MLInput.readLine();  }

}

//System.out.println("After while loop");
}
catch(java.io.IOException e){System.out.println(e);}}


protected void finalize() {
    try{
	//    MLOutput.write(("Quit();\n").toCharArray(),0,8);
	//    MLOutput.flush();

     //shut down the shell process and its reader
        MLInput.close();}
        catch(java.io.IOException e){System.out.println(e);}
	TheProcess.destroy();}


}





