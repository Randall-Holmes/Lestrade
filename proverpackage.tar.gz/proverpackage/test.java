import java.io.*;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

class test

{

    static class WorkingButton extends JButton implements ActionListener {

        //public JFrame TheInterface;

        public mlprocess TheProcess;

        public boolean go;

	public WorkingButton(String s,mlprocess x) {

	    super(s);addActionListener(this);go = false;TheProcess=x;
            // TheInterface = y;
            


	}

        public void actionPerformed(ActionEvent e) {

	    go = true;

	}}


    static class WorkingButton2 extends JButton implements ActionListener {

        public mlprocess TheProcess;

	public WorkingButton2(String s,mlprocess x) {

	    super(s);addActionListener(this);TheProcess = x;
            


	}

        public void actionPerformed(ActionEvent e) {

	    TheProcess.finalize();

	}}

    static class WorkingButton3 extends JButton implements ActionListener {

        public mlprocess TheProcess;

	public WorkingButton3(String s,mlprocess x) {

	    super(s);addActionListener(this);TheProcess = x;
        


	}

        public void actionPerformed(ActionEvent e) {

	    try{FileWriter F = new FileWriter(TheProcess.TheFileName);
            TheProcess.OutputTextArea.write(F);
            F.close();}
            catch(IOException ev){System.out.println(ev);}


	}}
static class WorkingButton4 extends JButton implements ActionListener {

    public mlprocess TheProcess;

    public JTextArea TheWindow;

    public WorkingButton4(String s,mlprocess x,JTextArea w) {

super(s);addActionListener(this);TheProcess = x;
TheWindow=w;


    }

public void actionPerformed(ActionEvent e) {

try{
    FileReader sourcefile = new FileReader(TheWindow.getText());
    TheProcess.OutputTextArea.setText("");
    TheProcess.OutputTextArea.read(sourcefile,null);
    TheProcess.TheFileName = TheWindow.getText();
}
catch(IOException ev){System.out.println(ev);}}

}

    static class KeyMonitor extends KeyAdapter {

        public mlprocess TheProcess;
        private boolean working = false;
        public JTextArea TheLocalWindow;

        public JTextArea TheGlobalWindow;

        public JTextArea TheEquationWindow;

        public KeyMonitor(mlprocess x,JTextArea y,JTextArea z,JTextArea u) {TheProcess = x;
TheLocalWindow=y;TheGlobalWindow=z; TheEquationWindow=u;}

	public void keyPressed(KeyEvent e) {

int Position = TheProcess.OutputTextArea.getCaretPosition();

	    //    System.out.println("Caught it!");

	    // idea is to insert appropriate text at the caret
            // in x's output text area, then submit the same
            // text to putwindow

	    if ((!working)&&e.getKeyCode() == e.VK_UP) {
		working = true;

TheProcess.OutputTextArea.insert
				 ("up();",Position);
//	    TheProcess.OutputTextArea.setSelectionStart(
//Position);
	    //TheProcess.OutputTextArea.setSelectionEnd(
//Position+7);
TheProcess.OutputTextArea.select(Position,Position+5);

TheProcess.putwindow(TheLocalWindow,TheGlobalWindow,TheEquationWindow);
working = false;}

	    if ((!working)&&e.getKeyCode() == e.VK_DOWN) {
		working = true;

TheProcess.OutputTextArea.insert
				 (";",Position);
//	    TheProcess.OutputTextArea.setSelectionStart(
//Position);
	    //TheProcess.OutputTextArea.setSelectionEnd(
//Position+7);
TheProcess.OutputTextArea.select(Position,Position+1);

TheProcess.putwindow(TheLocalWindow,TheGlobalWindow,TheEquationWindow);
working = false;}


            if ((!working)&&e.getKeyCode() == e.VK_RIGHT) {
working=true;
TheProcess.OutputTextArea.insert
				 ("right();",
Position);
//    TheProcess.OutputTextArea.setSelectionStart(
//Position);
//TheProcess.OutputTextArea.setSelectionEnd(
//Position+10);
TheProcess.OutputTextArea.select(Position,Position+8);

TheProcess.putwindow(TheLocalWindow,TheGlobalWindow,TheEquationWindow);
working=false;
	    }

            if ((!working)&&e.getKeyCode() == e.VK_LEFT) {
		working = true;
TheProcess.OutputTextArea.insert
				 ("left();",
Position);
//	    TheProcess.OutputTextArea.setSelectionStart(
//  Position);
//TheProcess.OutputTextArea.setSelectionEnd(
//(Position)+9);

TheProcess.OutputTextArea.select(Position,Position+7);
TheProcess.putwindow(TheLocalWindow,TheGlobalWindow,TheEquationWindow);
working = false;}

            if ((!working)&&e.getKeyCode() == e.VK_HOME) {
working = true;
TheProcess.OutputTextArea.insert
				 ("top();",
Position);
//	    TheProcess.OutputTextArea.setSelectionStart(
//Position);
//TheProcess.OutputTextArea.setSelectionEnd(
//Position+8);
TheProcess.OutputTextArea.select(Position,Position+6);

TheProcess.putwindow(TheLocalWindow,TheGlobalWindow,TheEquationWindow);
working = false;}

	}
    }

public static void main(String[] args)

{mlprocess x = new mlprocess(args[0]);

//    x.putquiet("load \"segments\";");
//        x.putquiet("open segments;");
    //     x.putstuff("start \"?x=?x\";");

JFrame aWindow1 = new JFrame("Command window");
JFrame aWindow2 = new JFrame("Display window");
JFrame aWindow3 = new JFrame("Local term window");
JFrame aWindow4 = new JFrame("Global term window");
JFrame aWindow5 = new JFrame("Equation window");
JTextArea TheLocalTerm = new JTextArea();
JTextArea TheGlobalTerm = new JTextArea();
JTextArea TheEquationWindow = new JTextArea();

KeyMonitor keychecker = new KeyMonitor(x,TheLocalTerm,TheGlobalTerm,TheEquationWindow);

aWindow3.getContentPane().add(TheLocalTerm);
aWindow4.getContentPane().add(TheGlobalTerm);
aWindow5.getContentPane().add(TheEquationWindow);

aWindow3.setVisible(true);
aWindow4.setVisible(true);
aWindow5.setVisible(true);
// aWindow1.getContentPane().add(x.OutputTextArea);

// button for submission of the text in the command window



WorkingButton SubmitButton = new WorkingButton("Submit",x);
TheGlobalTerm.addKeyListener(keychecker);
WorkingButton2 CloseButton = new WorkingButton2("Close",x);
WorkingButton3 SaveButton = new WorkingButton3("Save",x);
WorkingButton4 OpenButton = new WorkingButton4("Open",x,TheLocalTerm);

//JTextArea errorwindow = new JTextArea();

//errorwindow.setVisible(true);

Container content = aWindow1.getContentPane();

BorderLayout border= new BorderLayout();
JScrollPane scrollwindow2 = new JScrollPane(x.OutputTextArea);
content.setLayout(border);

content.add(SubmitButton,BorderLayout.NORTH);
content.add(SaveButton,BorderLayout.WEST);
content.add(scrollwindow2,BorderLayout.CENTER);
content.add(CloseButton,BorderLayout.SOUTH);
content.add(OpenButton,BorderLayout.EAST);
//content.add(errorwindow,BorderLayout.SOUTH);
JScrollPane scrollwindow = new JScrollPane(x.InputTextArea);


aWindow2.getContentPane().add(scrollwindow);
aWindow1.setBounds(200,200,800,400);
aWindow2.setBounds(1000,200,200,200);
aWindow4.setBounds(200,600,500,200);
aWindow3.setBounds(200,800,500,200);
aWindow5.setBounds(700,600,500,300);
aWindow1.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
aWindow2.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
aWindow1.setVisible(true);
aWindow2.setVisible(true);

Color R = new Color(200,200,0);
Color G = new Color(10,0,100);

x.InputTextArea.setVisible(true);
x.OutputTextArea.setVisible(true);

x.OutputTextArea.setSelectedTextColor(R);
x.OutputTextArea.setSelectionColor(G);
x.InputTextArea.setSelectedTextColor(R);
x.InputTextArea.setSelectionColor(G);
TheLocalTerm.setSelectedTextColor(R);
TheLocalTerm.setSelectionColor(G);
TheGlobalTerm.setSelectedTextColor(R);
TheGlobalTerm.setSelectionColor(G);
TheEquationWindow.setSelectedTextColor(R);
TheEquationWindow.setSelectionColor(G);

Font MyFont = new Font("Gothic",Font.PLAIN,14);

x.OutputTextArea.setFont(MyFont);
x.InputTextArea.setFont(MyFont);
TheLocalTerm.setFont(MyFont);
TheGlobalTerm.setFont(MyFont);
TheEquationWindow.setFont(MyFont);

scrollwindow.setVisible(true);

try{
    FileReader sourcefile = new FileReader(args[0]);
    x.OutputTextArea.read(sourcefile,null);
    x.TheFileName = args[0];
}
catch(IOException e){System.out.println(e);}

while (true)

    { if (SubmitButton.go) {x.putwindow(TheLocalTerm,TheGlobalTerm,TheEquationWindow); SubmitButton.go = false;}
    


    }


}}











